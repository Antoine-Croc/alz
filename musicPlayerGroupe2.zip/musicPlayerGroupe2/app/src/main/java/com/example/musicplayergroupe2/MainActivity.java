package com.example.musicplayergroupe2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.MediaStore;
import android.widget.Toast;

import com.example.musicplayergroupe2.Fragment.AudioFileListFragment;
import com.example.musicplayergroupe2.Fragment.PlayerFragment;
import com.example.musicplayergroupe2.Model.AudioFile;
import com.example.musicplayergroupe2.Service.PlayerService;
import com.example.musicplayergroupe2.Listener.CompletionListener;
import com.example.musicplayergroupe2.Listener.PlayerClickListener;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int STORAGE_PERMISSION_CODE = 101;
    List<AudioFile> audioFileList = new ArrayList<>();
    //Creation de notre service
    PlayerService mService;
    boolean mBound = false;
    CompletionListener listener = new CompletionListener() {
        @Override
        public void onAudioClick(AudioFile file,int position) {
            try {
                mService.play(file.getFilePath(),position);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    };
    PlayerClickListener toolBarListener = new PlayerClickListener() {

        @Override
        public void onPlayClick() {
            if(mService.isMediaPaused())
                mService.restart();
        }

        @Override
        public void onPauseClick(){
            if (mService.getMediaPlayer().isPlaying())
                mService.pause();
            else
                Toast.makeText(MainActivity.this, "PauseImpossible", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onPreviousClick() throws IOException {

            Toast.makeText(MainActivity.this, String.valueOf(mService.getCurrentSongIndex()), Toast.LENGTH_SHORT).show();
            mService.previous();

        }

        @Override
        public void onNextClick() throws IOException {
            mService.next();
        }

    };


    final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            // On recupere le service grace au binder
            PlayerService.PlayerBinder binder = (PlayerService.PlayerBinder) service;
            //on lie notre service
            mService =  binder.getService();
            mService.setAudioFileList(audioFileList);
            mBound = true;
        }
        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBound = false;
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkPermission(Manifest.permission.READ_EXTERNAL_STORAGE, STORAGE_PERMISSION_CODE);
        setContentView(R.layout.activity_main);
        populateAudioList();
        audioListListener();
        toolbar();
        Intent playerIntent = new Intent(this, PlayerService.class);
        bindService(playerIntent, this.mServiceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStart(){
        super.onStart();
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        AudioFileListFragment fragment = new AudioFileListFragment(audioFileList);
        fragment.setMyListener(listener);
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }

    private void populateAudioList() {
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI; // La carte SD
        String[] projection = {MediaStore.Audio.Media.DATA, MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,  MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION};
        //chemin du fichier, ID, titre, artist
        Cursor cursor = this.getContentResolver().query(uri,projection,null,null,null);
        //path peut être utilisé directement avec Mediaplayer.setDataSource(path)
        while(cursor.moveToNext()){
            int dataIndex = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
            int titleIndex = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int artistIndex = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int albumIndex = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
            int durationIndex = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
            String data = cursor.getString(dataIndex);
            String title = cursor.getString(titleIndex);
            String album = cursor.getString(albumIndex);
            String artist = cursor.getString(artistIndex);
            String duration = cursor.getString(durationIndex);
            AudioFile file=new AudioFile(title);
            file.setFilePath(data);
            file.setAlbum(album);
            file.setArtist(artist);
            file.setDuration(Integer.parseInt(duration));
            this.audioFileList.add(file);
        }
        cursor.close();
    }

    public void audioListListener() {

    }

    public void toolbar(){
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        PlayerFragment player = new PlayerFragment();
        player.setMyListener(toolBarListener);
        transaction.replace(R.id.fragment_player, player);
        transaction.commit();
    }

    public void checkPermission(String permission, int requestCode)
    {
        if (ContextCompat.checkSelfPermission(MainActivity.this, permission) == PackageManager.PERMISSION_DENIED) {

            // Requesting the permission
            ActivityCompat.requestPermissions(MainActivity.this, new String[] { permission }, requestCode);
        }
        else {
            Toast.makeText(MainActivity.this, "Permission already granted", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode,
                permissions,
                grantResults);

        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(MainActivity.this, "Storage Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Storage Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }


}