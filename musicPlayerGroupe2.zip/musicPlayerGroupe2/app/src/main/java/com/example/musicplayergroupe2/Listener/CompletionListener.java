package com.example.musicplayergroupe2.Listener;

import android.view.View;

import com.example.musicplayergroupe2.Model.AudioFile;

public interface CompletionListener {

    public void onAudioClick(AudioFile file, int position);

}