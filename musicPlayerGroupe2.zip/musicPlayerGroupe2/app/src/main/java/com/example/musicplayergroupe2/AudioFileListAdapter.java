package com.example.musicplayergroupe2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.example.musicplayergroupe2.Listener.CompletionListener;
import com.example.musicplayergroupe2.Model.AudioFile;
import com.example.musicplayergroupe2.databinding.AudioFileItemBinding;

import java.util.List;

public class AudioFileListAdapter extends RecyclerView.Adapter<AudioFileListAdapter.ViewHolder> {
    List<AudioFile> audioFileList;
    CompletionListener listener;
    public AudioFileListAdapter(List<AudioFile> fileList) {
        assert fileList != null;
        audioFileList = fileList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        AudioFileItemBinding binding = DataBindingUtil.inflate(
                LayoutInflater.from(parent.getContext()),
                R.layout.audio_file_item, parent,false);
        ViewHolder view = new ViewHolder(binding);

        return view;
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AudioFile file = audioFileList.get(position);
        holder.setPosition(position);
        holder.viewModel.setAudioFile(file);
    }

    @Override
    public int getItemCount() {
        return audioFileList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private AudioFileItemBinding binding;
        private AudioFileViewModel viewModel = new AudioFileViewModel();
        int position;
        ViewHolder(AudioFileItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
            this.binding.setAudioFileViewModel(viewModel);
            binding.getRoot().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener != null)
                        listener.onAudioClick(viewModel.getAudioFile(),position);
                }
            });
        }
        public void setPosition(int position){
            this.position=position;
        }
    }

    public void setMyListener(CompletionListener listener){
        this.listener = listener;
    }
}
