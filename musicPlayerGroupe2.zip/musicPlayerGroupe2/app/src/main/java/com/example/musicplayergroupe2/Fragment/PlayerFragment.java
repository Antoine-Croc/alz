package com.example.musicplayergroupe2.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.musicplayergroupe2.R;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.example.musicplayergroupe2.databinding.PlayerBinding;
import com.example.musicplayergroupe2.Listener.PlayerClickListener;

import java.io.IOException;

public class PlayerFragment extends Fragment{
    PlayerClickListener toolBarListener;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        PlayerBinding binding = DataBindingUtil.inflate(inflater,
                R.layout.player, container, false);
        binding.buttonPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(toolBarListener!=null){
                    toolBarListener.onPlayClick();
                }
            }
        });
        binding.buttonPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(toolBarListener!=null){
                    toolBarListener.onPauseClick();
                }
            }
        });
        binding.buttonPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(toolBarListener!=null){
                    try {
                        toolBarListener.onPreviousClick();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        binding.buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(toolBarListener!=null){
                    try {
                        toolBarListener.onNextClick();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        return binding.getRoot();
    }

    public void setMyListener(PlayerClickListener toolBarListener){
        this.toolBarListener=toolBarListener;
    }
}

