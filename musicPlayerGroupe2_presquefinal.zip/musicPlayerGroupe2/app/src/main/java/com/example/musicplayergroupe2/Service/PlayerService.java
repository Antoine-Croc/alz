package com.example.musicplayergroupe2.Service;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;

import androidx.annotation.Nullable;

import com.example.musicplayergroupe2.Model.AudioFile;

import java.io.IOException;
import java.util.List;

public class PlayerService extends Service implements MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnCompletionListener{

    List<AudioFile> audioFileList;

    public boolean isPaused=false;
    public int indCurrentMusic;

    MediaPlayer medPlayer = new MediaPlayer();
    private final Binder binder = new PlayerBinder();

    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY_COMPATIBILITY;
    }

    public void play(String path,int position) throws IOException {
        this.indCurrentMusic=position;
        medPlayer.reset();
        medPlayer.setDataSource(path);
        medPlayer.setOnCompletionListener(this::onCompletion);
        medPlayer.setOnPreparedListener(this::onPrepared);
        medPlayer.prepareAsync();
    }

    public void pause(){
        medPlayer.pause();
        this.isPaused=true;
    }

    public void restart(){
        medPlayer.start();
        this.isPaused=false;
    }

    public void next() throws IOException {
        if(indCurrentMusic<this.audioFileList.size()-1){
            AudioFile next_song = this.audioFileList.get(indCurrentMusic+1);
            this.play(next_song.getFilePath(),indCurrentMusic+1);
        }
        else{
            AudioFile next_song = this.audioFileList.get(0);
            this.play(next_song.getFilePath(),indCurrentMusic+1);
        }
    }

    public void previous() throws IOException {
        if(this.indCurrentMusic>0){
            AudioFile previous_song = this.audioFileList.get(this.indCurrentMusic-1);
            this.play(previous_song.getFilePath(), this.indCurrentMusic-1);
        }

        else{
            AudioFile previous_song = this.audioFileList.get(this.audioFileList.size()-1);
            this.play(previous_song.getFilePath(), this.audioFileList.size()-1);
        }

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }
    public void onPrepared(MediaPlayer player) {
        player.start();
    }
    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        return false;
    }

    @Override
    public void onCompletion(MediaPlayer medPlayer) {
        if(indCurrentMusic + 1 != audioFileList.size()) {
            try {
                this.play(audioFileList.get(indCurrentMusic+1).getFilePath(),indCurrentMusic+1);
            } catch (IOException e) {//permet d'imprimer les erreurs lors de l'usage du débugger
                //e.printStackTrace();
            }
        }
        else {
            try {
                this.play(audioFileList.get(0).getFilePath(),indCurrentMusic+1);
            } catch (IOException e) {
                //e.printStackTrace();
            }
        }
    }

    public class PlayerBinder extends Binder {
        public PlayerService getService() {
            return PlayerService.this;
        }
    }
    public MediaPlayer getMediaPlayer(){
        return this.medPlayer;
    }
    public boolean isMediaPaused(){return this.isPaused;}

    public int getCurrentSongIndex(){
        return this.indCurrentMusic;
    }

    public void setAudioFileList(List<AudioFile> audioFileList){
        this.audioFileList=audioFileList;
    }
}
