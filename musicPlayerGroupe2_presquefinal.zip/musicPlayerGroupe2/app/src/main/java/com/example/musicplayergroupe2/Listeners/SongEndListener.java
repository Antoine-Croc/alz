package com.example.musicplayergroupe2.Listeners;

import com.example.musicplayergroupe2.Model.AudioFile;

public interface SongEndListener {

    public void onAudioClick(AudioFile file, int position);

}