package com.example.musicplayergroupe2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.musicplayergroupe2.Listeners.SongEndListener;
import com.example.musicplayergroupe2.Model.AudioFile;
import com.example.musicplayergroupe2.databinding.AudioFileListFragmentBinding;

import java.util.List;

public class AudioFileListFragment extends Fragment {
    private List<AudioFile> audioFileList;
    private AudioFileListAdapter adapter;
    private SongEndListener listener;
    public AudioFileListFragment(List<AudioFile> audioFileList){
        this.audioFileList = audioFileList;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        AudioFileListFragmentBinding binding = DataBindingUtil.inflate(inflater,
                R.layout.audio_file_list_fragment, container, false);
        binding.audioFileList.setLayoutManager(new LinearLayoutManager(
                binding.getRoot().getContext()));
        adapter = new AudioFileListAdapter(audioFileList);
        adapter.setMyListener(listener);
        binding.audioFileList.setAdapter(adapter);
        return binding.getRoot();
    }

    public void setMyListener(SongEndListener listener) {
        if (adapter != null)
            adapter.setMyListener(listener);
        this.listener = listener;
    }
}

