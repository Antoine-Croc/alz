package com.example.musicplayergroupe2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.MediaStore;
import android.widget.Toast;

import com.example.musicplayergroupe2.Model.AudioFile;
import com.example.musicplayergroupe2.Service.PlayerService;
import com.example.musicplayergroupe2.Listeners.SongEndListener;
import com.example.musicplayergroupe2.Listeners.PlayerClickListener;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int STORAGE_PERMISSION_CODE = 101;
    List<AudioFile> audioFileList = new ArrayList<>();
    SongEndListener SListener = new SongEndListener() {
        @Override
        public void onAudioClick(AudioFile file,int position) {
            try {
                mService.play(file.getFilePath(),position);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    };
    boolean mBind = false;
    PlayerService mService;
    PlayerClickListener playerListener = new PlayerClickListener() {

        @Override
        public void onPlayClick() {
            if(mService.isMediaPaused())
                mService.restart();
        }

        @Override
        public void onPauseClick(){
            if (mService.getMediaPlayer().isPlaying())
                mService.pause();
            else
                Toast.makeText(MainActivity.this, "PauseImpossible", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onPreviousClick() throws IOException {
            Toast.makeText(MainActivity.this, String.valueOf(mService.getCurrentSongIndex()), Toast.LENGTH_SHORT).show();
            mService.previous();
        }

        @Override
        public void onNextClick() throws IOException {
            mService.next();
        }
    };

    final ServiceConnection mServConn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            // On veut recuperer le service avec le binder puis on le lie à l'application
            PlayerService.PlayerBinder binder = (PlayerService.PlayerBinder) service;

            mService =  binder.getService();
            mService.setAudioFileList(audioFileList);

            mBind = true;
        }
        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBind = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkPermission(Manifest.permission.READ_EXTERNAL_STORAGE, STORAGE_PERMISSION_CODE);
        setContentView(R.layout.activity_main);
        populateAudioList();
        audioListListener();
        player();
        Intent playerIntent = new Intent(this, PlayerService.class);
        bindService(playerIntent, this.mServConn, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStart(){
        super.onStart();
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        AudioFileListFragment fragment = new AudioFileListFragment(audioFileList);
        fragment.setMyListener(SListener);
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }

    private void populateAudioList() {
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI; //Localisation du contenu de la carte SD
        String[] projection = {MediaStore.Audio.Media.DATA, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,  MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION};
        //On récupere les chemins des données(titres, artistes, albums,...)
        Cursor cursor = this.getContentResolver().query(uri,projection,null,null,null);
        while(cursor.moveToNext()){
            int indArtist = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int indAlbum = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
            int indData = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
            int indDuration = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
            int duration = Integer.parseInt(cursor.getString(indDuration));
            int titleIndex = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
            String data = cursor.getString(indData);
            String title = cursor.getString(titleIndex);
            String album = cursor.getString(indAlbum);
            String artist = cursor.getString(indArtist);
            AudioFile file=new AudioFile();
            file.setTitle(title);
            file.setFilePath(data);
            file.setAlbum(album);
            file.setArtist(artist);
            file.setDuration(duration);
            this.audioFileList.add(file);
        }
        cursor.close();
    }

    public void audioListListener() { }

    public void player(){
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        PlayerFragment player = new PlayerFragment();
        player.setMyListener(playerListener);
        transaction.replace(R.id.fragment_player, player); //va permettre de binder le système du "player" en bas de l'écran à l'appli
        transaction.commit();
    }

    public void checkPermission(String permission, int requestCode)
    {
        if (ContextCompat.checkSelfPermission(MainActivity.this, permission) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[] {permission}, requestCode);
        } //On fait une demande d'autorisation d'accès sur le device
        else {
            Toast.makeText(MainActivity.this, "Permission granted", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //Cette fonction va permettre la vérification de permissions
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(MainActivity.this, "Storage Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Storage Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }


}