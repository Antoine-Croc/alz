package com.example.musicplayergroupe2.Listeners;

import java.io.IOException;

public interface PlayerClickListener {

    public void onPlayClick();
    public void onPauseClick();
    public void onPreviousClick() throws IOException;
    public void onNextClick() throws IOException;
}
