package com.example.myapplication.Model;


import com.example.myapplication.Listener.AudioClickListener;

import java.util.Locale;

public class AudioFile {
    private int Id;
    private String title;
    private String filePath;
    private String artist;
    private String album;
    private String genre;
    private int year;
    private int duration;
    private AudioClickListener myListener;

    //setters
    public void setId(int id) {
        this.Id=id;
    }
    public void setTitle(String title) { this.title = title; }
    public void setFilePath(String filePath) { this.filePath = filePath; }
    public void setArtist(String artist) {
        this.artist = artist;
    }
    public void setAlbum(String album) {
        this.album = album;
    }
    public void setDuration(int duration) {
        this.duration = duration/1000;
    }
    public void setGenre(String genre) {
        this.genre = genre;
    }
    public void setYear(int year) {
        this.year = year;
    }

    //getters
    public int getId(){return this.Id;}
    public String getArtist() { return artist; }
    public String getTitle() { return title; }
    public String getFilePath() { return filePath; }
    public String getAlbum() {
        return album;
    }
    public String getGenre() {
        return genre;
    }
    public int getYear() {
        return year;
    }
    public int getDuration() {
        return duration;
    }
    public String getDurationText() {
        int second = duration % 60;
        int durationMinute = (duration - second) / 60;
        int minute = durationMinute % 60;
        int hour = (durationMinute - minute) / 60;
        if(hour > 0)
            return String.format(Locale.getDefault(),
                    "%02d:%02d:%02d",hour,minute,second);
        return String.format(Locale.getDefault(),
                "%02d:%02d",minute,second);
    }

}