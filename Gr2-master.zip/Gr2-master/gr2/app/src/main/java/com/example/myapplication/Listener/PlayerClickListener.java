package com.example.myapplication.Listener;

import java.io.IOException;

public interface PlayerClickListener {
    public void onPlayPauseClick() throws IOException;
    //public void onPauseClick();
    public void onPreviousClick() throws IOException;
    public void onNextClick() throws IOException;
}
