package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.MediaStore;
import android.widget.Toast;

import com.example.myapplication.Fragment.AudioFileListFragment;
import com.example.myapplication.Fragment.PlayerFragment;
import com.example.myapplication.Model.AudioFile;
import com.example.myapplication.Service.PlayerService;
import com.example.myapplication.Listener.CompletionListener;
import com.example.myapplication.Listener.AudioClickListener;
import com.example.myapplication.Listener.PlayerClickListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int STORAGE_PERMISSION_CODE = 101;
    List<AudioFile> audioFileList = new ArrayList<>();
    PlayerService audioService;
    AudioFileListFragment audioFragment;
    boolean boolConnect = false;
    CompletionListener completionListen = new CompletionListener() {
        @Override
        public void completeTrack() {
            audioFragment.upIndex();
            audioFragment.scrollDown(audioService.currentSongIndex+1);
        }
    };
    AudioClickListener audioclickListener = new AudioClickListener(){
        @Override
        public void onAudioClick(AudioFile file,int position) {
            try {
                audioService.play(file.getFilePath(),position);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    };
    PlayerClickListener playerClickListener = new PlayerClickListener() {
        @Override
        public void onPlayPauseClick() throws IOException {
            if (audioService.isMediaPaused()) {
                audioService.restart();
            } else if (audioService.isMediaPlaying()) {
                audioService.pause();
            } else{
                audioService.playFirst();
            }
        }

        @Override
        public void onPreviousClick() throws IOException {
            audioFragment.downIndex();
            audioService.previous();
        }

        @Override
        public void onNextClick() throws IOException {
            audioFragment.upIndex();
            audioService.next();
        }

    };

    final ServiceConnection audioServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            if(!boolConnect){
                boolConnect = true;
                // On veut recuperer le service avec le binder puis on le lie
                PlayerService.PlayerBinder binder = (PlayerService.PlayerBinder) service;
                audioService =  binder.getService();
                audioService.setAudioFileList(audioFileList);
                audioService.setCompleteListener(completionListen);
            }
        }
        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            boolConnect = false;
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkPermission(Manifest.permission.READ_EXTERNAL_STORAGE, STORAGE_PERMISSION_CODE);
        setContentView(R.layout.activity_main);
        populateAudioList();
        displayPlayer();
        Intent playerIntent = new Intent(this, PlayerService.class);
        bindService(playerIntent, this.audioServiceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStart(){
      super.onStart();
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        AudioFileListFragment fragment = new AudioFileListFragment(audioFileList);
        this.audioFragment=fragment;
        fragment.setMyListener(audioclickListener);
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }

    private void populateAudioList() {
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI; // La carte SD
        String[] projection = { MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DATA, MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.DURATION};
        Cursor cursor = this.getContentResolver().query(uri,projection,null,null,null);
        while(cursor.moveToNext()){
            int indArtist = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int indAlbum = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM);
            int indData = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
            int indDuration = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
            int duration = Integer.parseInt(cursor.getString(indDuration));
            int indId = cursor.getColumnIndex(MediaStore.Audio.Media._ID);
            int id = cursor.getInt(indId);
            int titleIndex = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE);
            String data = cursor.getString(indData);
            String title = cursor.getString(titleIndex);
            String album = cursor.getString(indAlbum);
            String artist = cursor.getString(indArtist);
            AudioFile file=new AudioFile();
            file.setTitle(title);
            file.setId(id);
            file.setFilePath(data);
            file.setAlbum(album);
            file.setArtist(artist);
            file.setDuration(duration);
            this.audioFileList.add(file);
        }
        cursor.close();
    }

    public void displayPlayer(){
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        PlayerFragment player = new PlayerFragment();
        player.setMyListener(playerClickListener);
        transaction.replace(R.id.fragment_player, player);
        transaction.commit();
    }

    public void checkPermission(String permission, int requestCode)
    {
        if (ContextCompat.checkSelfPermission(MainActivity.this, permission) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[] { permission }, requestCode);
        }
        else {
            Toast.makeText(MainActivity.this, "Permission already granted", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(MainActivity.this, "Storage Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Storage Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }


}

