package com.example.myapplication;

import android.content.Context;
import android.graphics.Color;
//import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Listener.AudioClickListener;
import com.example.myapplication.Model.AudioFile;
import com.example.myapplication.databinding.AudioFileItemBinding;

import java.util.List;

public class AudioFileListAdapter extends RecyclerView.Adapter<AudioFileListAdapter.ViewHolder> {
    List<AudioFile> audioFileList;
    AudioClickListener listener;
    int position=0;
    Context context;
    public AudioFileListAdapter(List<AudioFile> fileList,Context context) {
        assert fileList != null;
        audioFileList = fileList;
        this.context=context;
    }
    public void changePosition(int position){
        this.position=position;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        AudioFileItemBinding binding = DataBindingUtil.inflate(
                LayoutInflater.from(parent.getContext()),
                R.layout.audio_file_item, parent,false);
         ViewHolder view = new ViewHolder(binding);

        return view;
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AudioFile file = audioFileList.get(position);
        holder.setPosition(position);
        holder.viewModel.setAudioFile(file);
        if(position == this.position){
            holder.itemView.setBackground(this.context.getResources().getDrawable(R.drawable.border));
        }
        else
        {
            holder.itemView.setBackgroundColor(Color.parseColor("#FF00FF"));
        }
    }

    @Override
    public int getItemCount() {
        return audioFileList.size();
    }

    public void upIndex() {
        if(position!=this.audioFileList.size()-1){
            updateBorder(this.position+1);
        }
        else{
            updateBorder(0);
        }

    }
    public void downIndex(){
        if(position!=0){
            updateBorder(this.position-1);
        }
        else{
            updateBorder(this.audioFileList.size()-1);
        }
    }

    public void updateBorder(int position){
        int temp_variable=this.position;
        changePosition(position);
        notifyItemChanged(position);
        notifyItemChanged(temp_variable);
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private AudioFileItemBinding binding;
        private AudioFileViewModel viewModel = new AudioFileViewModel();
        int position;
        ViewHolder(AudioFileItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
            this.binding.setAudioFileViewModel(viewModel);

            binding.getRoot().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener != null){
                        listener.onAudioClick(viewModel.getAudioFile(),position);
                    }
                    updateBorder(position);
                }
            });
        }
        public void setPosition(int position){
            this.position=position;
        }
    }

    public void setMyListener(AudioClickListener listener){
        this.listener = listener;
    }
}
