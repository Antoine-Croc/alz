package com.example.myapplication.Service;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;

import androidx.annotation.Nullable;

import com.example.myapplication.Model.AudioFile;
import com.example.myapplication.Listener.CompletionListener;

import java.io.IOException;
import java.util.List;


public class PlayerService extends Service implements MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnCompletionListener{

    List<AudioFile> audioFileList;
    public boolean isPaused=false;
    public int currentSongIndex;

    MediaPlayer mediaPlayer = new MediaPlayer();
    private final Binder binder = new PlayerBinder();
    private CompletionListener completionListener;
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY_COMPATIBILITY;
    }

    public void play(String path,int position) throws IOException {
        this.isPaused=false;
        this.currentSongIndex=position;
        mediaPlayer.reset();
        mediaPlayer.setDataSource(path);
        mediaPlayer.setOnCompletionListener(this::onCompletion);
        mediaPlayer.setOnPreparedListener(this::onPrepared);
        mediaPlayer.prepareAsync();
    }

    public void pause(){
        mediaPlayer.pause();
        this.isPaused=true;
    }

    public void restart(){
        mediaPlayer.start();
        this.isPaused=false;
    }

    public void next() throws IOException {
        if(currentSongIndex<this.audioFileList.size()-1){
            AudioFile next_song = this.audioFileList.get(currentSongIndex+1);
            this.play(next_song.getFilePath(),currentSongIndex+1);
        }
        else{
            AudioFile next_song = this.audioFileList.get(0);
            this.play(next_song.getFilePath(),0);
        }

    }

    public void previous() throws IOException {
        if(this.currentSongIndex>0){
            AudioFile previous_song = this.audioFileList.get(this.currentSongIndex-1);
            this.play(previous_song.getFilePath(), this.currentSongIndex-1);
        }

        else{
            AudioFile previous_song = this.audioFileList.get(this.audioFileList.size()-1);
            this.play(previous_song.getFilePath(), this.audioFileList.size()-1);
        }

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }
    public void onPrepared(MediaPlayer player) {
        player.start();
    }
    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        return false;
    }

    @Override
    public void onCompletion(MediaPlayer mediaPlayer) {
        this.completionListener.completeTrack();
        if(currentSongIndex != audioFileList.size()-1) {
            try {
                this.play(audioFileList.get(currentSongIndex+1).getFilePath(),currentSongIndex+1);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else {
            try {
                this.play(audioFileList.get(0).getFilePath(),currentSongIndex+1);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean isMediaPlaying() {
        return mediaPlayer.isPlaying();
    }

    public void playFirst() throws IOException {
        AudioFile audio = this.audioFileList.get(0);
        this.play(audio.getFilePath(), 0);
    }

    public class PlayerBinder extends Binder {
        public PlayerService getService() {
            return PlayerService.this;
        }
    }
    public boolean isMediaPaused(){return this.isPaused;}

    public void setAudioFileList(List<AudioFile> audioFileList){
        this.audioFileList=audioFileList;
    }

    public void setCompleteListener(CompletionListener listener){
        this.completionListener=listener;
    }
}