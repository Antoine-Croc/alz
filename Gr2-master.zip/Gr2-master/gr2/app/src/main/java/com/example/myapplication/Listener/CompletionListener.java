package com.example.myapplication.Listener;

public interface CompletionListener {
    public void completeTrack();
}
