package com.example.myapplication.Listener;

import com.example.myapplication.Model.AudioFile;

public interface AudioClickListener {

    public void onAudioClick(AudioFile file, int position);

}


