package com.example.myapplication.Fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Model.AudioFile;
import com.example.myapplication.AudioFileListAdapter;
import com.example.myapplication.R;
import com.example.myapplication.databinding.AudioFileListFragmentBinding;
import com.example.myapplication.Listener.AudioClickListener;

import java.util.List;

public class AudioFileListFragment extends Fragment {
    private List<AudioFile> audioFileList;
    private AudioFileListAdapter adapter;
    private AudioClickListener listener;
    RecyclerView recyclerView;
    public AudioFileListFragment(List<AudioFile> audioFileList){
        this.audioFileList = audioFileList;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        AudioFileListFragmentBinding binding = DataBindingUtil.inflate(inflater,
                R.layout.audio_file_list_fragment, container, false);

        binding.audioFileList.setLayoutManager(new LinearLayoutManager(
                binding.getRoot().getContext()));
        this.recyclerView=binding.audioFileList;
        adapter = new AudioFileListAdapter(audioFileList,this.getContext());
        adapter.setMyListener(listener);
        binding.audioFileList.setAdapter(adapter);
        return binding.getRoot();
    }

    public void setMyListener(AudioClickListener listener) {
        if (adapter != null)
            adapter.setMyListener(listener);
        this.listener = listener;
    }

    public void upIndex(){
        this.adapter.upIndex();
    }

    public void downIndex(){
        this.adapter.downIndex();
    }

    public void scrollDown(int position) {
        Log.i("position",String.valueOf(position));
        recyclerView.scrollToPosition(position);
    }
}
