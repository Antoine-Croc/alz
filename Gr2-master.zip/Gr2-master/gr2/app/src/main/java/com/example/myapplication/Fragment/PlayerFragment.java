package com.example.myapplication.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.example.myapplication.Listener.PlayerClickListener;
import com.example.myapplication.R;
import com.example.myapplication.databinding.PlayerBinding;

import java.io.IOException;


public class PlayerFragment extends Fragment {
    PlayerClickListener playerClickListener;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        PlayerBinding binding = DataBindingUtil.inflate(inflater,
                R.layout.player, container, false);
        binding.buttonPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(playerClickListener !=null){
                    try {
                        playerClickListener.onPlayPauseClick();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        binding.buttonPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(playerClickListener !=null){
                    try {

                        playerClickListener.onPreviousClick();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        binding.buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(playerClickListener !=null){
                    try {
                        playerClickListener.onNextClick();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        return binding.getRoot();
    }

    public void setMyListener(PlayerClickListener playerClickListener){
        this.playerClickListener = playerClickListener;
    }
}
